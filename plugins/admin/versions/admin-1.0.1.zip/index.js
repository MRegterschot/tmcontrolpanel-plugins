"use strict";
(() => {
  // @tmcontrolpanel/plugin-sdk/src/index.ts
  function definePlugin(definition) {
    const register = globalThis.__tmcpRegister;
    if (typeof register === "function") register(definition);
    return definition;
  }

  // plugins/admin/src/index.ts
  var NotifyAdminPlugin = class {
    constructor(ctx) {
      this.ctx = ctx;
      this.widget = ctx.ui.widget({
        id: "notify-admin-widget",
        template: "widgets/notify-admin/notify-admin",
        withUpdate: false,
        position: { x: 119, y: -70 },
        hideWhileDriving: true,
        data: { notifyAdminAction: "notify-admin-action" }
      });
      ctx.action("notify-admin-action", (answer) => this.notify(answer.login));
      ctx.command("admin", (args, login) => this.notify(login, args.join(" ") || void 0));
    }
    widget;
    start() {
      this.widget.display();
    }
    async notify(login, description) {
      const player = await this.ctx.players.get(login);
      await this.ctx.notifyAdmins(
        `${player.nickName} asked for help on server ${this.ctx.serverName()}`,
        description
      );
      await this.ctx.chat.sendTo(login, "Admins have been notified");
    }
  };
  var index_default = definePlugin({
    create: (ctx) => new NotifyAdminPlugin(ctx)
  });
})();
