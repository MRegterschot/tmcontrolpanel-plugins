"use strict";
(() => {
  // ../packages/plugin-sdk/src/helpers.ts
  var MapList = class {
    constructor(ctx) {
      this.ctx = ctx;
    }
    async getAll() {
      const pageSize = 100;
      let all = [];
      for (let start = 0; ; start += pageSize) {
        const batch = await this.ctx.gbx.call("GetMapList", pageSize, start);
        if (!Array.isArray(batch) || batch.length === 0) break;
        all = all.concat(batch);
        if (batch.length < pageSize) break;
      }
      if (all.length === 0) throw new Error("Failed to retrieve the map list from the server");
      return all;
    }
    // Unknown files are skipped
    async getInfos(fileNames) {
      const infos = [];
      for (const fileName of fileNames) {
        try {
          const info = await this.ctx.gbx.call("GetMapInfo", fileName);
          if (info) infos.push(info);
        } catch (error) {
          this.ctx.log.warn(`Failed to get map info for ${fileName}`, { error: String(error) });
        }
      }
      return infos;
    }
    // Makes the map list exactly fileNames, in that order
    async replace(fileNames) {
      await this.ctx.gbx.call("RemoveMapList", fileNames);
      const added = await this.ctx.gbx.call("AddMapList", fileNames);
      if (typeof added !== "number") throw new Error("Failed to add maps to the map list");
      const others = (await this.getAll()).map((map) => map.FileName).filter((fileName) => !fileNames.includes(fileName));
      const removed = await this.ctx.gbx.call("RemoveMapList", others);
      if (typeof removed !== "number") throw new Error("Failed to remove maps from the map list");
    }
    async jumpTo(index) {
      await this.ctx.gbx.call("JumpToMapIndex", index);
    }
    async restart() {
      await this.ctx.gbx.call("RestartMap");
    }
  };

  // ../packages/plugin-sdk/src/index.ts
  function definePlugin(definition) {
    const register = globalThis.__tmcpRegister;
    if (typeof register === "function") register(definition);
    return definition;
  }

  // match/src/pickban.ts
  function stringToPickAndBan(str) {
    if (!str) return [];
    return str.split(",").map((item) => {
      const [action, seed] = item.trim().split(":");
      if (action === "p") return { action: "pick", seed: parseInt(seed, 10) };
      if (action === "b") return { action: "ban", seed: parseInt(seed, 10) };
      if (action === "r") return { action: "random" };
      throw new Error(`Invalid pick and ban item: ${item}`);
    });
  }
  function applySeedsOverride(order, seeds) {
    if (seeds.length === 0) return order;
    const uniqueSeeds = [
      ...new Set(order.flatMap((item) => item.action === "random" ? [] : [item.seed]))
    ].sort((a, b) => a - b);
    const replacements = /* @__PURE__ */ new Map();
    seeds.forEach((seed, i) => {
      if (i < uniqueSeeds.length) replacements.set(uniqueSeeds[i], seed);
    });
    return order.map(
      (item) => item.action === "random" ? item : { ...item, seed: replacements.get(item.seed) ?? item.seed }
    );
  }
  function availablePositions(order) {
    return order.filter((item) => item.action === "pick" || item.action === "random").map((_, i) => i + 1);
  }
  var PickBan = class {
    constructor(setup, nickNameOf, random = Math.random) {
      this.nickNameOf = nickNameOf;
      this.random = random;
      this.mode = setup.mode;
      this.choosePosition = setup.choosePosition;
      this.maps = setup.maps;
      this.order = setup.order;
      this.players = setup.players;
      this.teams = setup.teams;
      this.positionsAvailable = availablePositions(setup.order);
      this.turn = this.computeTurn();
    }
    mode;
    choosePosition;
    maps;
    positionsAvailable;
    order;
    players;
    teams;
    picked = /* @__PURE__ */ new Map();
    currentIndex = 0;
    turn;
    // Map waiting for its position (choosePosition mode)
    pendingMapUid = null;
    get currentTurn() {
      return this.turn;
    }
    get isDone() {
      return this.currentIndex >= this.maps.length || this.turn === null;
    }
    // Final map list in position order
    pickedFileNames() {
      return [...this.picked.entries()].sort(([a], [b]) => a - b).map(([, file]) => file);
    }
    advance() {
      this.currentIndex += 1;
      this.pendingMapUid = null;
      this.turn = this.computeTurn();
      return this.turn;
    }
    select(login, uid, activeLogins) {
      const turn = this.turn;
      if (!turn) return { kind: "noTurn" };
      if (this.mode === "player" && turn.login !== login) return { kind: "notYourTurn" };
      if (this.mode === "team" && !turn.players.includes(login)) return { kind: "notYourTurn" };
      const map = this.maps.find((m) => m.uid === uid);
      if (!map) return { kind: "mapNotFound" };
      if (map.pickedBy || map.bannedBy) return { kind: "mapUnavailable" };
      if (this.mode === "team") {
        if (!map.selectedBy.includes(login)) map.selectedBy.push(login);
        for (const other of this.maps) {
          if (other !== map && !other.pickedBy && !other.bannedBy) {
            other.selectedBy = other.selectedBy.filter((l) => l !== login);
          }
        }
        const votes = map.selectedBy.filter((l) => turn.players.includes(l)).length;
        const activeTeamPlayers = activeLogins.filter((l) => turn.players.includes(l)).length;
        if (votes <= activeTeamPlayers / 2) return { kind: "voteRegistered" };
      } else if (turn.action === "pick" && this.choosePosition) {
        this.pendingMapUid = map.uid;
        return { kind: "choosePosition" };
      }
      if (turn.action === "pick") {
        this.pickAt(map, turn.nickName, this.picked.size + 1);
      } else if (turn.action === "ban") {
        map.bannedBy = turn.nickName;
      }
      return { kind: "applied", map };
    }
    // Completes a choosePosition pick; false when the position is not available
    choosePositionFor(position) {
      const turn = this.turn;
      const map = this.maps.find((m) => m.uid === this.pendingMapUid);
      const slot = this.positionsAvailable.indexOf(position);
      if (!turn || !map || slot === -1) return null;
      this.positionsAvailable.splice(slot, 1);
      this.pickAt(map, turn.nickName, position);
      this.pendingMapUid = null;
      return map;
    }
    // Explicit "random" step: always a pick, by "random"
    pickRandom() {
      const map = this.randomAvailableMap();
      if (!map) return null;
      this.pickAt(map, "random", this.nextAutoPosition());
      return map;
    }
    // Timed-out turn: apply the turn's own action to a random map on the player's behalf
    resolveTimeout() {
      const turn = this.turn;
      if (!turn) return null;
      const map = this.randomAvailableMap();
      if (!map) return null;
      if (turn.action === "ban") {
        map.bannedBy = turn.nickName;
      } else {
        this.pickAt(map, turn.nickName, this.nextAutoPosition());
      }
      return map;
    }
    pickAt(map, by, position) {
      this.picked.set(position - 1, map.filename);
      map.pickedBy = by;
      map.index = position;
    }
    nextAutoPosition() {
      if (this.mode === "player" && this.choosePosition) {
        const next = this.positionsAvailable.shift();
        if (next !== void 0) return next;
      }
      return this.picked.size + 1;
    }
    randomAvailableMap() {
      const available = this.maps.filter((m) => !m.pickedBy && !m.bannedBy);
      if (available.length === 0) return null;
      return available[Math.floor(this.random() * available.length)] ?? null;
    }
    computeTurn() {
      const step = this.order[this.currentIndex];
      if (!step) return null;
      if (step.action === "random") {
        return { action: "random", login: "", players: [], nickName: "" };
      }
      if (this.mode === "player") {
        const player = this.players.find((p) => p.seed === step.seed);
        if (!player) return { action: step.action, login: "", players: [], nickName: "" };
        return {
          action: step.action,
          login: player.login,
          players: [],
          nickName: this.nickNameOf(player.login) || player.login
        };
      }
      const team = this.teams.find((t) => t.seed === step.seed);
      if (!team) return { action: step.action, login: "", players: [], nickName: "" };
      return {
        action: step.action,
        login: "",
        players: team.players,
        nickName: team.name || `Team ${step.seed}`
      };
    }
  };

  // match/src/index.ts
  function normalizeConfig(raw) {
    const config = raw && typeof raw === "object" ? raw : {};
    const pickAndBan = config.pickAndBan;
    if (!pickAndBan) return config;
    const timeout = Number(pickAndBan.timeout);
    return {
      ...config,
      pickAndBan: {
        ...pickAndBan,
        order: pickAndBan.order ?? "",
        choosePosition: pickAndBan.choosePosition ?? false,
        timeout: Number.isFinite(timeout) && timeout > 0 ? timeout : void 0
      }
    };
  }
  function errorMessage(error) {
    return error instanceof Error ? error.message : String(error);
  }
  var PICKBAN_DONE_DELAY_MS = 1e4;
  var RANDOM_STEP_DELAY_MS = 1e3;
  function capitalize(text) {
    return text.charAt(0).toUpperCase() + text.slice(1);
  }
  var MatchPlugin = class {
    constructor(ctx) {
      this.ctx = ctx;
      this.maps = new MapList(ctx);
      this.widget = ctx.ui.widget({
        id: "match-pickban-widget",
        template: "widgets/match/pickban",
        position: { x: -60, y: 67 }
      });
      ctx.command("matchstart", (_, login) => this.onMatchStart(login));
      ctx.command("matchstop", (_, login) => this.onMatchStop(login));
      ctx.command("pause", (_, login) => this.onPause(login, true));
      ctx.command("unpause", (_, login) => this.onPause(login, false));
      ctx.command("pickban", (_, login) => this.onPickBanStart(login));
      ctx.command("lobby", (_, login) => this.onLobby(login));
      ctx.command("setseeds", (args, login) => this.onSetSeeds(args, login));
      ctx.action(
        "match-pickban-action-{uid}",
        (answer, params) => this.onMapSelected(answer, params.uid)
      );
      ctx.action(
        "match-pickban-choose-position-{position}",
        (answer, params) => this.onPositionChosen(answer, parseInt(params.position, 10))
      );
    }
    widget;
    positionWindows = /* @__PURE__ */ new Map();
    state = "not_started";
    pickBan = null;
    seedsOverride = [];
    cancelTurnTimeout = null;
    maps;
    stop() {
      this.clearTurnTimeout();
    }
    get matchState() {
      return this.state;
    }
    config() {
      return normalizeConfig(this.ctx.config());
    }
    tell(login, message) {
      return this.ctx.chat.sendTo(login, message);
    }
    authorize(login, message) {
      if (this.config().admins?.includes(login)) return true;
      void this.tell(login, message || "You are not authorized to perform this action");
      return false;
    }
    // Runs a step and reports failures to the admin instead of throwing
    async attempt(login, label, step) {
      try {
        await step();
        return true;
      } catch (error) {
        this.ctx.log.error(label, { error: errorMessage(error) });
        await this.tell(login, `${label}: ${errorMessage(error)}`);
        return false;
      }
    }
    async onMatchStart(login) {
      if (!this.authorize(login, "You are not authorized to start the match")) return;
      if (this.state === "pickban") {
        return this.tell(login, "Pick and ban phase is still in progress, cannot start the match");
      }
      if (this.state === "in_progress") {
        return this.tell(login, "Match has already started, cannot start the match");
      }
      const config = this.config();
      if (config?.script) {
        const ok = await this.attempt(login, "Failed to load match script", async () => {
          await this.ctx.server.setScriptName(config.script);
          await this.ctx.chat.send(`Loaded match script: ${config.script}`);
        });
        if (!ok) return;
      }
      if (this.state === "not_started" && config?.maps?.length) {
        const ok = await this.attempt(
          login,
          "Failed to set map list",
          () => this.maps.replace(config.maps)
        );
        if (!ok) return;
      }
      if (this.state === "ready") {
        const picked = this.pickBan?.pickedFileNames() ?? [];
        if (picked.length === 0) {
          return this.tell(login, "No maps have been picked, cannot start the match");
        }
        const ok = await this.attempt(
          login,
          "Failed to set map list",
          () => this.maps.replace(picked)
        );
        if (!ok) return;
      }
      if (await this.goToFirstMap(login, "Failed to start the match")) {
        this.state = "in_progress";
      }
      await this.attempt(login, "Failed to fetch map list", async () => {
        const maps = await this.maps.getAll();
        await this.ctx.chat.send(
          `Maps:
${maps.map((map, index) => `$z${index + 1}. ${map.Name}`).join("\n")}`
        );
      });
    }
    async onMatchStop(login) {
      if (!this.authorize(login, "You are not authorized to stop the match")) return;
      this.widget.destroy();
      this.clearTurnTimeout();
      this.state = "not_started";
      await this.ctx.chat.send("Match stopped");
      await this.applyLobby(login);
    }
    async onPause(login, pause) {
      const verb = pause ? "pause" : "unpause";
      if (!this.authorize(login, `You are not authorized to ${verb} the match`)) return;
      const { liveInfo } = this.ctx.live;
      if (!liveInfo.pauseAvailable) {
        return this.tell(login, "Pausing is not available in this mode");
      }
      if (pause && liveInfo.isPaused) return this.tell(login, "Match is already paused");
      if (!pause && !liveInfo.isPaused) return this.tell(login, "Match is not paused");
      await this.attempt(login, `Failed to ${verb} the match`, async () => {
        const player = this.ctx.live.findActivePlayer(login);
        await this.ctx.server.setPaused(pause);
        await this.ctx.chat.send(
          `Match ${pause ? "paused" : "unpaused"} by ${player?.nickName || login}`
        );
      });
    }
    async onPickBanStart(login) {
      if (!this.authorize(login, "You are not authorized to start the pick and ban phase")) return;
      if (this.state === "pickban") {
        return this.tell(login, "Pick and ban phase is already in progress");
      }
      if (this.state !== "not_started") {
        return this.tell(login, "Match has already started, cannot start pick and ban phase");
      }
      const config = this.config().pickAndBan;
      if (!config?.type) return this.tell(login, "Pick and ban configuration is not set");
      const order = applySeedsOverride(stringToPickAndBan(config.order), this.seedsOverride);
      this.pickBan = new PickBan(
        {
          mode: config.type,
          order,
          choosePosition: config.choosePosition,
          players: config.players ?? [],
          teams: config.teams ?? [],
          maps: await this.loadMaps(this.config().maps ?? [])
        },
        (l) => this.ctx.live.findActivePlayer(l)?.nickName
      );
      this.state = "pickban";
      this.startTurnTimer();
      this.renderPickBan(true);
      await this.ctx.chat.send(
        `Pick and ban phase started
${order.map(
          (step) => step.action !== "random" ? `${step.seed}: ${capitalize(step.action)}` : "Random"
        ).join("\n")}`
      );
      await this.runAutomaticSteps();
    }
    async onLobby(login) {
      if (!this.authorize(login, "You are not authorized to execute this command")) return;
      if (this.state !== "not_started") {
        return this.tell(login, "Match has already started, cannot go to lobby");
      }
      const lobby = this.config().lobby;
      if (!lobby || !lobby.map && !lobby.script) {
        return this.tell(login, "Lobby configuration is not set");
      }
      await this.applyLobby(login);
    }
    async onSetSeeds(args, login) {
      const seeds = args.map((arg) => parseInt(arg, 10));
      if (seeds.some((seed) => isNaN(seed))) {
        return this.tell(login, "Invalid seed(s) provided, please provide valid numbers");
      }
      this.seedsOverride = seeds;
      await this.tell(
        login,
        seeds.length === 0 ? "Seeds for pick and ban order have been cleared" : `Seeds for pick and ban order have been set to: ${seeds.join(", ")}`
      );
    }
    async onMapSelected(answer, uid) {
      const pickBan = this.pickBan;
      if (!uid || !pickBan) return;
      const activeLogins = this.ctx.live.activePlayers.map((p) => p.login);
      const result = pickBan.select(answer.login, uid, activeLogins);
      switch (result.kind) {
        case "noTurn":
          return this.tell(answer.login, "No pick and ban action is currently active");
        case "mapNotFound":
          return this.tell(answer.login, "Selected map not found");
        case "notYourTurn":
        case "mapUnavailable":
          return;
        case "voteRegistered":
          return this.renderPickBan();
        case "choosePosition":
          return this.openPositionWindow(answer.login);
        case "applied":
          return this.nextTurn();
      }
    }
    async onPositionChosen(answer, position) {
      const pickBan = this.pickBan;
      const turn = pickBan?.currentTurn;
      if (!pickBan || !turn || turn.login !== answer.login || isNaN(position)) return;
      if (!pickBan.choosePositionFor(position)) return;
      this.closePositionWindow(turn.login);
      await this.nextTurn();
    }
    async nextTurn() {
      const pickBan = this.pickBan;
      if (!pickBan) return;
      pickBan.advance();
      this.startTurnTimer();
      this.renderPickBan();
      await this.runAutomaticSteps();
    }
    // Plays random steps and finishes the phase once no turns are left
    async runAutomaticSteps() {
      const pickBan = this.pickBan;
      if (!pickBan) return;
      while (!pickBan.isDone && pickBan.currentTurn?.action === "random") {
        await this.ctx.sleep(RANDOM_STEP_DELAY_MS);
        if (!pickBan.pickRandom()) {
          await this.ctx.chat.send("Failed to handle random pick and ban, no available maps left");
          return;
        }
        pickBan.advance();
        this.startTurnTimer();
        this.renderPickBan();
      }
      if (pickBan.isDone) {
        this.clearTurnTimeout();
        await this.ctx.sleep(PICKBAN_DONE_DELAY_MS);
        this.state = "ready";
        await this.ctx.chat.send("Pick and ban phase completed, match is ready to start");
        this.widget.destroy();
      }
    }
    startTurnTimer() {
      this.clearTurnTimeout();
      const turn = this.pickBan?.currentTurn;
      const timeout = this.config().pickAndBan?.timeout;
      if (!turn || turn.action === "random" || !timeout || timeout <= 0) return;
      turn.timeoutSeconds = timeout;
      this.cancelTurnTimeout = this.ctx.setTimeout(() => {
        this.cancelTurnTimeout = null;
        void this.onTurnTimeout();
      }, timeout * 1e3);
    }
    clearTurnTimeout() {
      this.cancelTurnTimeout?.();
      this.cancelTurnTimeout = null;
    }
    async onTurnTimeout() {
      const pickBan = this.pickBan;
      const turn = pickBan?.currentTurn;
      if (!pickBan || !turn) return;
      if (turn.login) this.closePositionWindow(turn.login);
      const map = pickBan.resolveTimeout();
      if (!map) {
        await this.ctx.chat.send("Failed to handle pick/ban timeout, no available maps left");
        return;
      }
      await this.ctx.chat.send(
        `${turn.nickName || "The current player"} ran out of time, ${map.name} was randomly ${turn.action === "ban" ? "banned" : "picked"} for them`
      );
      await this.nextTurn();
    }
    renderPickBan(display = false) {
      const pickBan = this.pickBan;
      if (!pickBan) return;
      this.widget.setData({
        pickBanAction: "match-pickban-action",
        mapInfosJson: JSON.stringify(pickBan.maps),
        currentActionJson: pickBan.currentTurn ? JSON.stringify(pickBan.currentTurn) : void 0
      });
      if (display) {
        this.widget.display();
      } else {
        this.widget.update();
      }
    }
    openPositionWindow(login) {
      const pickBan = this.pickBan;
      if (!pickBan?.currentTurn || this.positionWindows.has(login)) return;
      const window = this.ctx.ui.window({
        id: "choose-position-window",
        template: "windows/match/choose-position-window",
        login,
        title: "Choose Position",
        withUpdate: false,
        size: { x: pickBan.positionsAvailable.length * 12 + 2, y: 14 },
        data: {
          currentAction: pickBan.currentTurn,
          positionsAvailable: pickBan.positionsAvailable,
          choosePositionAction: "match-pickban-choose-position"
        },
        onClose: () => this.positionWindows.delete(login)
      });
      this.positionWindows.set(login, window);
      window.display();
    }
    closePositionWindow(login) {
      this.positionWindows.get(login)?.destroy();
      this.positionWindows.delete(login);
    }
    // Prefers map rows from the database; falls back to the server for unknown files
    async loadMaps(fileNames) {
      const fromDb = new Map(
        (await this.ctx.maps.findByFileNames(fileNames)).map((map) => [map.fileName, map])
      );
      const missing = fileNames.filter((fileName) => !fromDb.has(fileName));
      const fromServer = new Map(
        (missing.length > 0 ? await this.maps.getInfos(missing) : []).map((map) => [
          map.FileName,
          map
        ])
      );
      return fileNames.flatMap((fileName) => {
        const base = { index: 0, selectedBy: [], pickedBy: "", bannedBy: "" };
        const db = fromDb.get(fileName);
        if (db) {
          return [{ ...base, name: db.name, author: db.author, uid: db.uid, filename: db.fileName }];
        }
        const server = fromServer.get(fileName);
        if (!server) return [];
        return [
          { ...base, name: server.Name, author: server.Author, uid: server.UId, filename: server.FileName }
        ];
      });
    }
    async applyLobby(login) {
      const lobby = this.config().lobby;
      if (lobby?.script) {
        await this.attempt(login, "Failed to load lobby script", async () => {
          await this.ctx.server.setScriptName(lobby.script);
          await this.ctx.chat.send(`Loaded lobby script: ${lobby.script}`);
        });
      }
      if (lobby?.map) {
        await this.attempt(
          login,
          "Failed to set lobby map",
          () => this.maps.replace([lobby.map])
        );
      }
      if (await this.goToFirstMap(login, "Failed to go to lobby")) {
        this.state = "not_started";
      }
    }
    // Jumping to index 0 fails when already on it; a restart has the same effect then
    async goToFirstMap(login, failure) {
      try {
        await this.maps.jumpTo(0);
        return true;
      } catch {
        return this.attempt(login, failure, () => this.maps.restart());
      }
    }
  };
  var index_default = definePlugin({
    create: (ctx) => new MatchPlugin(ctx)
  });
})();
