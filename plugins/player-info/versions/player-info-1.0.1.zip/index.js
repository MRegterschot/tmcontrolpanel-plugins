"use strict";
(() => {
  // @tmcontrolpanel/plugin-sdk/src/helpers.ts
  var BASE64URL = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_";
  function loginToAccountId(login) {
    if (login.includes("fakeplayer") || !/^[A-Za-z0-9_-]{22}$/.test(login)) return null;
    const bytes = [];
    let buffer = 0;
    let bits = 0;
    for (const char of login) {
      buffer = buffer << 6 | BASE64URL.indexOf(char);
      bits += 6;
      if (bits >= 8) {
        bits -= 8;
        bytes.push(buffer >> bits & 255);
      }
    }
    if (bytes.length !== 16) return null;
    const hex = bytes.map((byte) => byte.toString(16).padStart(2, "0")).join("");
    return `${hex.slice(0, 8)}-${hex.slice(8, 12)}-${hex.slice(12, 16)}-${hex.slice(16, 20)}-${hex.slice(20)}`;
  }

  // @tmcontrolpanel/plugin-sdk/src/index.ts
  function definePlugin(definition) {
    const register = globalThis.__tmcpRegister;
    if (typeof register === "function") register(definition);
    return definition;
  }

  // plugins/player-info/src/index.ts
  var PlayerInfoPlugin = class {
    constructor(ctx) {
      this.ctx = ctx;
      this.widget = ctx.ui.widget({
        id: "player-info-widget",
        template: "widgets/player-info/player-info",
        position: { x: -156, y: -49 }
      });
      ctx.on("beginMap", () => this.refreshAll());
      ctx.on("playerConnect", (player) => this.onPlayerConnect(player));
      ctx.on("finish", (waypoint) => this.onFinish(waypoint));
    }
    widget;
    cards = {};
    async start() {
      this.widget.display();
      await this.refreshAll();
    }
    onConfigUpdate() {
      for (const card of Object.values(this.cards)) {
        Object.assign(card, this.setupFor(card.login));
      }
      this.render();
    }
    setupFor(login) {
      const configured = this.ctx.config().playerInfos?.find((p) => p.login === login);
      return {
        device: configured?.device || "Unknown",
        camera: configured?.camera || "Unknown"
      };
    }
    onFinish(waypoint) {
      const card = this.cards[waypoint.login];
      if (!card) return;
      let changed = false;
      if (!card.personalBest || waypoint.racetime < card.personalBest) {
        card.personalBest = waypoint.racetime;
        changed = true;
      }
      if (!card.localRecord || waypoint.racetime < card.localRecord) {
        card.localRecord = waypoint.racetime;
        changed = true;
      }
      if (changed) this.render();
    }
    async onPlayerConnect(player) {
      if (this.cards[player.login]) return;
      const mapUid = this.ctx.live.activeMapUid;
      const [localRecords, personalBests] = mapUid ? await Promise.all([
        this.localRecords(mapUid, [player.login]),
        this.personalBests(mapUid, [player.login])
      ]) : [/* @__PURE__ */ new Map(), /* @__PURE__ */ new Map()];
      this.cards[player.login] = {
        login: player.login,
        name: player.nickName,
        localRecord: localRecords.get(player.login) ?? 0,
        personalBest: personalBests.get(player.login) ?? 0,
        ...this.setupFor(player.login)
      };
      this.render();
    }
    async refreshAll() {
      const players = this.ctx.live.activePlayers.filter(
        (player) => !player.login.includes("fakeplayer")
      );
      if (players.length === 0) {
        this.cards = {};
        this.render();
        return;
      }
      const map = await this.ctx.gbx.call("GetCurrentMapInfo");
      const logins = players.map((p) => p.login);
      const [localRecords, personalBests] = await Promise.all([
        this.localRecords(map.UId, logins),
        this.personalBests(map.UId, logins)
      ]);
      this.cards = {};
      for (const player of players) {
        this.cards[player.login] = {
          login: player.login,
          name: player.nickName,
          personalBest: personalBests.get(player.login) ?? 0,
          localRecord: localRecords.get(player.login) ?? 0,
          ...this.setupFor(player.login)
        };
      }
      this.render();
    }
    async localRecords(mapUid, logins) {
      try {
        const records = await this.ctx.records.forPlayers(mapUid, logins);
        return new Map(records.filter((r) => r.login).map((r) => [r.login, r.time]));
      } catch (error) {
        this.ctx.log.error("Failed to fetch player records", { error: String(error) });
        return /* @__PURE__ */ new Map();
      }
    }
    // Keyed by login
    async personalBests(mapUid, logins) {
      const accounts = logins.map((login) => [login, loginToAccountId(login)]).filter((entry) => entry[1] !== null);
      if (accounts.length === 0) return /* @__PURE__ */ new Map();
      try {
        const byAccount = await this.ctx.nadeo.personalBests(
          mapUid,
          accounts.map(([, accountId]) => accountId)
        );
        return new Map(
          accounts.filter(([, accountId]) => accountId in byAccount).map(([login, accountId]) => [login, byAccount[accountId]])
        );
      } catch (error) {
        this.ctx.log.error("Failed to fetch personal bests", { error: String(error) });
        return /* @__PURE__ */ new Map();
      }
    }
    render() {
      this.widget.setData({ playerInfosJson: JSON.stringify(Object.values(this.cards)) });
      this.widget.update();
    }
  };
  var index_default = definePlugin({
    create: (ctx) => new PlayerInfoPlugin(ctx)
  });
})();
