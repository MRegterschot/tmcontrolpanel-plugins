"use strict";
(() => {
  // ../packages/plugin-sdk/src/helpers.ts
  function getSpectatorStatus(spectatorStatus) {
    return {
      spectator: spectatorStatus % 10 === 1,
      temporarySpectator: Math.floor(spectatorStatus / 10) % 10 === 1,
      pureSpectator: Math.floor(spectatorStatus / 100) % 10 === 1,
      autoTarget: Math.floor(spectatorStatus / 1e3) % 10 === 1,
      currentTargetId: Math.floor(spectatorStatus / 1e4)
    };
  }
  var TEAM_COLORS = {
    red: { mainColor: "A22", secondaryColor: "922", textColor: "DDD" },
    blue: { mainColor: "22A", secondaryColor: "229", textColor: "DDD" },
    default: { mainColor: "", secondaryColor: "", textColor: "" }
  };
  function getTeamColors(teamName) {
    if (!teamName) return TEAM_COLORS.default;
    return TEAM_COLORS[teamName.toLowerCase()] ?? TEAM_COLORS.default;
  }
  var BASE64URL = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_";
  function loginToAccountId(login) {
    if (login.includes("fakeplayer") || !/^[A-Za-z0-9_-]{22}$/.test(login)) return null;
    const bytes = [];
    let buffer = 0;
    let bits = 0;
    for (const char of login) {
      buffer = buffer << 6 | BASE64URL.indexOf(char);
      bits += 6;
      if (bits >= 8) {
        bits -= 8;
        bytes.push(buffer >> bits & 255);
      }
    }
    if (bytes.length !== 16) return null;
    const hex = bytes.map((byte) => byte.toString(16).padStart(2, "0")).join("");
    return `${hex.slice(0, 8)}-${hex.slice(8, 12)}-${hex.slice(12, 16)}-${hex.slice(16, 20)}-${hex.slice(20)}`;
  }
  function throttle(ctx, fn, ms) {
    let waiting = false;
    let pending = false;
    const run = () => {
      fn();
      waiting = true;
      ctx.setTimeout(() => {
        waiting = false;
        if (pending) {
          pending = false;
          run();
        }
      }, ms);
    };
    return () => {
      if (waiting) pending = true;
      else run();
    };
  }

  // ../packages/plugin-sdk/src/index.ts
  function definePlugin(definition) {
    const register = globalThis.__tmcpRegister;
    if (typeof register === "function") register(definition);
    return definition;
  }

  // live-round/src/index.ts
  function sortRoundEntries(entries) {
    return [...entries].sort((a, b) => {
      if (b.checkpoints.length !== a.checkpoints.length) {
        return b.checkpoints.length - a.checkpoints.length;
      }
      if (a.time !== b.time) return a.time - b.time;
      for (let i = a.checkpoints.length; i >= 0; i--) {
        if (a.checkpoints[i] !== b.checkpoints[i]) return a.checkpoints[i] - b.checkpoints[i];
      }
      return 0;
    });
  }
  var LiveRoundPlugin = class {
    constructor(ctx) {
      this.ctx = ctx;
      this.widget = ctx.ui.widget({
        id: "live-round-widget",
        template: "widgets/live-round/live-round",
        position: { x: -156, y: 73.5 }
      });
      this.render = throttle(ctx, () => this.send(), 100);
      ctx.on("beginMap", () => this.onBeginMap());
      ctx.on("beginMatch", () => this.reset());
      ctx.on("startRound", () => this.reset());
      ctx.on("playerConnect", (player) => this.onPlayerConnect(player));
      ctx.on("playerInfo", (player) => this.onPlayerInfo(player));
      ctx.on("playerDisconnect", (login) => this.onPlayerDisconnect(login));
      ctx.on("checkpoint", (waypoint) => this.onCheckpoint(waypoint));
      ctx.on("finish", (waypoint) => this.onFinish(waypoint));
      ctx.on("giveUp", (event) => this.onGiveUp(event));
      ctx.on("updatedSettings", (info) => this.onUpdatedSettings(info));
      ctx.on("scores", (scores) => this.onScores(scores));
      ctx.on("playerUpdated", (round) => this.onPlayerUpdated(round));
    }
    widget;
    liveFastestTime = null;
    rounds = [];
    finishes = [];
    // Badges are decided when a finish happens; renders are throttled and run after the record moved
    recordSetters = { local: /* @__PURE__ */ new Set(), world: /* @__PURE__ */ new Set() };
    pointsLimit = -1;
    pointsRepartition = [];
    worldRecord = 0;
    localRecord = 0;
    // Personal best per login
    personalBests = {};
    render;
    async start() {
      this.widget.display();
      await this.reset();
      await this.refreshRecords();
    }
    newEntry(login, name, teamId, teams = this.ctx.live.liveInfo.teams) {
      return {
        login,
        name,
        rank: 0,
        time: 0,
        checkpoints: [],
        points: 0,
        team: getTeamColors(teams?.[teamId]?.name)
      };
    }
    isOut(login, spectatorStatus) {
      const status = this.ctx.live.reverseCupGetPlayerStatus(login);
      return getSpectatorStatus(spectatorStatus).spectator || status.spectator || status.eliminated;
    }
    async onPlayerConnect(player) {
      const map = await this.ctx.gbx.call("GetCurrentMapInfo");
      const accountId = loginToAccountId(player.login);
      try {
        const bests = accountId ? await this.ctx.nadeo.personalBests(map.UId, [accountId]) : {};
        this.personalBests[player.login] = accountId && bests[accountId] || 0;
      } catch (error) {
        this.ctx.log.error("Failed to fetch personal best on connect", { error: String(error) });
        this.personalBests[player.login] ??= 0;
      }
      if (this.isOut(player.login, player.spectatorStatus)) return;
      if (this.rounds.some((r) => r.login === player.login)) return;
      this.rounds.push(this.newEntry(player.login, player.nickName, player.teamId));
      this.render();
    }
    onPlayerDisconnect(login) {
      if (!this.rounds.some((r) => r.login === login)) return;
      this.rounds = this.rounds.filter((r) => r.login !== login);
      this.render();
    }
    onPlayerInfo(player) {
      const round = this.rounds.find((r) => r.login === player.login);
      if (this.isOut(player.login, player.spectatorStatus)) {
        if (!round) return;
        this.rounds = this.rounds.filter((r) => r.login !== player.login);
      } else if (!round) {
        this.rounds.push(this.newEntry(player.login, player.nickName, player.teamId));
      } else {
        Object.assign(round, {
          ...this.newEntry(player.login, player.nickName, player.teamId),
          points: round.points
        });
      }
      this.render();
    }
    onPlayerUpdated(playerRound) {
      const round = this.rounds.find((r) => r.login === playerRound.login);
      if (!round) return;
      round.points = playerRound.matchPoints;
      this.render();
    }
    async onBeginMap() {
      this.liveFastestTime = null;
      await this.reset();
      await this.refreshRecords();
    }
    onUpdatedSettings(info) {
      this.pointsLimit = info.pointsLimit || -1;
      this.pointsRepartition = info.pointsRepartition || [];
      this.render();
    }
    onCheckpoint(waypoint) {
      if (this.ctx.live.liveInfo.isWarmUp) return;
      const round = this.rounds.find((r) => r.login === waypoint.login);
      if (!round) return;
      round.time = waypoint.racetime;
      round.checkpoints = waypoint.curracecheckpoints;
      this.render();
    }
    onFinish(waypoint) {
      if (this.ctx.live.liveInfo.isWarmUp || waypoint.racetime === 0) return;
      let isFastest = false;
      if (this.liveFastestTime === null || waypoint.racetime < this.liveFastestTime) {
        this.liveFastestTime = waypoint.racetime;
        isFastest = true;
      }
      const round = this.rounds.find((r) => r.login === waypoint.login);
      if (!round) return;
      round.time = waypoint.racetime;
      round.checkpoints = waypoint.curracecheckpoints;
      const personalBest = this.personalBests[waypoint.login] ?? 0;
      const isLocalRecord = isFastest && this.beatsLocalRecord(waypoint.racetime);
      const isWorldRecord = isFastest && this.beatsWorldRecord(waypoint.racetime);
      this.finishes.push({
        login: waypoint.login,
        points: 0,
        isPersonalBest: personalBest > 0 && waypoint.racetime < personalBest,
        isLocalRecord,
        isWorldRecord
      });
      if (personalBest === 0 || waypoint.racetime < personalBest) {
        this.personalBests[waypoint.login] = waypoint.racetime;
      }
      if (isLocalRecord) {
        this.localRecord = waypoint.racetime;
        this.recordSetters.local.add(waypoint.login);
      }
      if (isWorldRecord) {
        this.worldRecord = waypoint.racetime;
        this.recordSetters.world.add(waypoint.login);
      }
      this.render();
    }
    onGiveUp(event) {
      if (this.ctx.live.liveInfo.isWarmUp) return;
      const round = this.rounds.find((r) => r.login === event.login);
      if (!round) return;
      round.time = -1;
      this.render();
    }
    onScores(scores) {
      if (scores.responseid !== this.ctx.pluginId && scores.section !== "EndRound") return;
      const { liveInfo } = this.ctx.live;
      for (const player of scores.players) {
        const round = this.rounds.find((r) => r.login === player.login);
        if (!round) continue;
        if (player.matchpoints > this.pointsLimit && this.pointsLimit > 0 && liveInfo.type !== "teams") {
          this.rounds = this.rounds.filter((r) => r.login !== player.login);
        } else {
          round.points = player.matchpoints;
        }
      }
      if (liveInfo.type === "reversecup") {
        this.rounds = this.rounds.filter((r) => r.points > -2e3);
      }
      this.render();
    }
    async refreshRecords() {
      const map = await this.ctx.gbx.call("GetCurrentMapInfo");
      const logins = this.ctx.live.activePlayers.map((p) => p.login).filter((login) => !login.includes("fakeplayer"));
      if (!map) {
        this.worldRecord = 0;
        this.localRecord = 0;
        this.personalBests = Object.fromEntries(logins.map((login) => [login, 0]));
        return;
      }
      const local = await this.ctx.records.local(map.UId);
      this.localRecord = local ? local.time : 0;
      try {
        this.worldRecord = (await this.ctx.nadeo.worldRecord(map.UId))?.score ?? 0;
      } catch (error) {
        this.ctx.log.error("Failed to fetch world record", { error: String(error) });
        this.worldRecord = 0;
      }
      try {
        const accounts = logins.map((login) => [login, loginToAccountId(login)]).filter((entry) => entry[1] !== null);
        const bests = await this.ctx.nadeo.personalBests(
          map.UId,
          accounts.map(([, accountId]) => accountId)
        );
        for (const [login, accountId] of accounts) {
          this.personalBests[login] = bests[accountId] ?? 0;
        }
      } catch (error) {
        this.ctx.log.error("Failed to fetch personal bests", { error: String(error) });
        for (const login of logins) this.personalBests[login] ??= 0;
      }
    }
    async reset() {
      const { liveInfo } = this.ctx.live;
      this.pointsLimit = liveInfo.pointsLimit || -1;
      this.pointsRepartition = liveInfo.pointsRepartition || [];
      this.finishes = [];
      this.recordSetters.local.clear();
      this.recordSetters.world.clear();
      this.rounds = [];
      const playerList = await this.ctx.gbx.call("GetPlayerList", 1e3, 0);
      const mainServer = await this.ctx.gbx.call("GetMainServerPlayerInfo");
      for (const player of Array.isArray(playerList) ? playerList : []) {
        if (!player.Login || player.Login === mainServer?.Login) continue;
        if (this.isOut(player.Login, player.SpectatorStatus)) continue;
        this.rounds.push(this.newEntry(player.Login, player.NickName, player.TeamId, liveInfo.teams));
      }
      await this.ctx.gbx.callScript("Trackmania.GetScores", this.ctx.pluginId);
    }
    send() {
      const { live } = this.ctx;
      const config = this.ctx.config();
      this.rounds = sortRoundEntries(this.rounds);
      this.rounds.forEach((round, index) => round.rank = index + 1);
      const rankOf = (login) => this.rounds.find((r) => r.login === login)?.rank;
      this.finishes.sort((a, b) => (rankOf(a.login) ?? 0) - (rankOf(b.login) ?? 0));
      this.finishes.forEach((finish, index) => {
        if (config?.showPoints === false) {
          finish.points = 0;
          return;
        }
        if (!rankOf(finish.login)) return;
        if (live.isReverseCup) {
          const playerCount = this.rounds.filter((r) => r.points > -2e3).length;
          const repartition = live.reverseCupGetPointsRepartition(playerCount);
          finish.points = -repartition[Math.min(index, repartition.length - 1)] || 0;
        } else {
          const position = Math.min(index, this.pointsRepartition.length - 1);
          finish.points = this.pointsRepartition[position] || 0;
        }
      });
      this.finishes.forEach((finish, index) => {
        finish.isLocalRecord = index === 0 && this.recordSetters.local.has(finish.login);
        finish.isWorldRecord = index === 0 && this.recordSetters.world.has(finish.login);
      });
      this.widget.setData({
        roundsJson: JSON.stringify(this.rounds),
        finishesJson: JSON.stringify(this.finishes),
        mode: live.liveInfo.type,
        pointsLimit: this.pointsLimit,
        localRecordText: config?.localRecordText || "LR",
        rowCount: config?.rowCount || 8
      });
      this.widget.update();
    }
    beatsLocalRecord(time) {
      return this.localRecord === 0 || time < this.localRecord;
    }
    beatsWorldRecord(time) {
      return time < this.worldRecord;
    }
  };
  var index_default = definePlugin({
    create: (ctx) => new LiveRoundPlugin(ctx)
  });
})();
