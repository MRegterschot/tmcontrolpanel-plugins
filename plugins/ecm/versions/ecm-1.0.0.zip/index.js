"use strict";
(() => {
  // ../packages/plugin-sdk/src/helpers.ts
  function rankPlayers(players, timeAttack) {
    return [...players].sort((a, b) => {
      const timeA = timeAttack ? a.bestracetime : a.prevracetime;
      const timeB = timeAttack ? b.bestracetime : b.prevracetime;
      if (timeA === -1 && timeB === -1) return 0;
      if (timeA === -1) return 1;
      if (timeB === -1) return -1;
      if (timeA !== timeB) return timeA - timeB;
      const cpA = timeAttack ? a.bestracecheckpoints : a.prevracecheckpoints;
      const cpB = timeAttack ? b.bestracecheckpoints : b.prevracecheckpoints;
      for (let i = Math.min(cpA.length, cpB.length) - 1; i >= 0; i--) {
        if (cpA[i] !== cpB[i]) return cpA[i] - cpB[i];
      }
      return 0;
    }).map((player, index) => ({ ...player, position: index + 1 }));
  }

  // ../packages/plugin-sdk/src/index.ts
  function definePlugin(definition) {
    const register = globalThis.__tmcpRegister;
    if (typeof register === "function") register(definition);
    return definition;
  }

  // ecm/src/index.ts
  var ECM_URL = "https://us-central1-fantasy-trackmania.cloudfunctions.net";
  var ECM_ICON = "https://i.imgur.com/DIjT0pA.png";
  function isValidEcmApiKey(key) {
    return !key || (key.match(/_/g) || []).length === 1;
  }
  function isEditor(config, login) {
    const editors = config.editors ?? [];
    return editors.length === 0 || editors.includes(login);
  }
  var ECMPlugin = class {
    constructor(ctx) {
      this.ctx = ctx;
      ctx.on("finish", (waypoint) => this.onFinish(waypoint));
      ctx.on("scores", (scores) => this.onScores(scores));
      ctx.on("beginMap", () => {
        this.roundOffset = 0;
        this.refreshWindows();
      });
      ctx.on("startRound", () => {
        this.activeDrivers.clear();
        this.refreshWindows();
      });
      ctx.on("startLine", (event) => this.activeDrivers.add(event.login));
      ctx.command("ecm", (_, login) => this.openWindow(login));
      ctx.action("open", (answer) => this.openWindow(answer.login));
      ctx.action("ecm-toggle-recording", (answer) => this.onToggleRecording(answer));
      ctx.action("ecm-save-api-key", (answer) => this.onSaveApiKey(answer));
      ctx.action("ecm-increase-round-offset", (answer) => this.onRoundOffset(answer, 1));
      ctx.action("ecm-decrease-round-offset", (answer) => this.onRoundOffset(answer, -1));
    }
    roundOffset = 0;
    activeDrivers = /* @__PURE__ */ new Set();
    windows = /* @__PURE__ */ new Map();
    start() {
      this.ctx.ui.addButton({ name: "ecm", icon: ECM_ICON, type: "image", action: "open" });
    }
    onConfigUpdate() {
      this.refreshWindows();
    }
    isActive() {
      const { live } = this.ctx;
      const { liveInfo } = live;
      const config = this.ctx.config();
      return !!live.activeMapUid && !liveInfo.isPaused && !liveInfo.isWarmUp && !!config.apiKey && !!config.isRecording;
    }
    roundNum() {
      return (this.ctx.live.roundNumber || 1) + this.roundOffset;
    }
    // Fire and forget: a failing report is logged, it never interrupts the game
    async post(endpoint, body) {
      const [matchId, authToken] = (this.ctx.config().apiKey ?? "").split("_");
      if (!matchId || !authToken) {
        this.ctx.log.warn("Invalid eCircuitMania API key");
        return;
      }
      try {
        const response = await this.ctx.http.fetch(
          `${ECM_URL}/${endpoint}?matchId=${encodeURIComponent(matchId)}`,
          {
            method: "POST",
            headers: { "Content-Type": "application/json", Authorization: authToken },
            body: JSON.stringify(body)
          }
        );
        if (response.status >= 400) {
          this.ctx.log.error("eCircuitMania request failed", {
            endpoint,
            status: response.status,
            body: response.body.slice(0, 500)
          });
        }
      } catch (error) {
        this.ctx.log.error("eCircuitMania request failed", { endpoint, error: String(error) });
      }
    }
    onFinish(waypoint) {
      if (!this.isActive()) return;
      void this.post("match-addRoundTime", {
        finishTime: waypoint.racetime,
        ubisoftUid: waypoint.accountid,
        roundNum: this.roundNum(),
        mapId: this.ctx.live.activeMapUid
      });
    }
    onScores(scores) {
      const type = this.ctx.live.liveInfo.type;
      const expectedSection = type === "reversecup" ? "PreEndRound" : "EndRound";
      if (scores.section !== expectedSection) return;
      if (!this.isActive()) return;
      const timeAttack = type === "timeattack";
      let players = scores.players;
      if (type === "reversecup") {
        players = players.filter((p) => p.matchpoints > -2e3);
      }
      if (!timeAttack) {
        players = players.filter((p) => p.prevracetime !== -1 || this.activeDrivers.has(p.login));
      }
      void this.post("match-addRound", {
        players: rankPlayers(players, timeAttack).map((p) => ({
          finishTime: timeAttack ? p.bestracetime : p.prevracetime,
          ubisoftUid: p.accountid,
          position: p.position
        })),
        roundNum: this.roundNum(),
        mapId: this.ctx.live.activeMapUid
      });
    }
    openWindow(login) {
      if (this.windows.has(login)) return;
      const window = this.ctx.ui.window({
        id: "ecm-window",
        template: "windows/ecm/ecm-window",
        login,
        title: "eCircuitMania",
        size: { x: 54, y: 32.5 },
        data: this.windowData(login),
        onClose: () => this.windows.delete(login)
      });
      this.windows.set(login, window);
      window.display();
    }
    windowData(login) {
      const config = this.ctx.config();
      const editor = isEditor(config, login);
      return {
        isEditor: editor,
        apiKey: editor ? config.apiKey || "" : "",
        isRecording: config.isRecording || false,
        currentRound: this.roundNum()
      };
    }
    refreshWindows() {
      for (const [login, window] of this.windows) {
        window.setData(this.windowData(login));
        window.update();
      }
    }
    canEdit(answer) {
      return this.windows.has(answer.login) && isEditor(this.ctx.config(), answer.login);
    }
    async onToggleRecording(answer) {
      if (!this.canEdit(answer)) return;
      const config = this.ctx.config();
      await this.ctx.saveConfig({ ...config, isRecording: !config.isRecording });
      this.refreshWindows();
    }
    async onSaveApiKey(answer) {
      if (!this.canEdit(answer)) return;
      const apiKey = answer.entries["ecm-api-key-entry"];
      if (!isValidEcmApiKey(apiKey)) return;
      await this.ctx.saveConfig({ ...this.ctx.config(), apiKey });
      this.refreshWindows();
    }
    onRoundOffset(answer, delta) {
      if (!this.canEdit(answer)) return;
      this.roundOffset += delta;
      this.refreshWindows();
    }
  };
  var index_default = definePlugin({
    create: (ctx) => new ECMPlugin(ctx)
  });
})();
