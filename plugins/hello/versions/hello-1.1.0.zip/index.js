"use strict";
(() => {
  // @tmcontrolpanel/plugin-sdk/src/index.ts
  function definePlugin(definition) {
    const register = globalThis.__tmcpRegister;
    if (typeof register === "function") register(definition);
    return definition;
  }

  // plugins/hello/src/index.ts
  var index_default = definePlugin({
    create(ctx) {
      let widget = null;
      let total = 0;
      const refresh = () => {
        if (!widget) return;
        widget.setData({
          text: `${ctx.config().greeting}! ${total} greetings so far`
        });
        widget.display();
      };
      const greet = async (login) => {
        const player = await ctx.players.get(login);
        const key = `greetings:${login}`;
        const count = (await ctx.storage.get(key) ?? 0) + 1;
        await ctx.storage.set(key, count);
        total++;
        await ctx.chat.sendTo(
          login,
          `${ctx.config().greeting} ${player.nickName}! (greeting #${count})`
        );
        refresh();
      };
      const applyConfig = () => {
        if (ctx.config().showWidget) {
          widget ??= ctx.ui.widget({
            id: "greeting",
            template: "widgets/greeting",
            withUpdate: false,
            position: { x: -158, y: 60 },
            hideWhileDriving: true
          });
          refresh();
        } else {
          widget?.destroy();
          widget = null;
        }
      };
      ctx.command("hello", (_args, login) => greet(login));
      ctx.on("playerConnect", (player) => greet(player.login));
      ctx.action("wave", (answer) => greet(answer.login));
      return {
        start: applyConfig,
        onConfigUpdate: applyConfig
      };
    }
  });
})();
