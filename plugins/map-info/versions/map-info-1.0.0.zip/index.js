"use strict";
(() => {
  // ../packages/plugin-sdk/src/index.ts
  function definePlugin(definition) {
    const register = globalThis.__tmcpRegister;
    if (typeof register === "function") register(definition);
    return definition;
  }

  // map-info/src/index.ts
  var UNKNOWN = { name: "-", author: "-" };
  var MapInfoPlugin = class {
    constructor(ctx) {
      this.ctx = ctx;
      this.widget = ctx.ui.widget({
        id: "map-info-widget",
        template: "widgets/map-info/map-info",
        position: { x: 100, y: 85 },
        hideWhileDriving: true
      });
      ctx.on("beginMap", () => this.refresh());
    }
    widget;
    async start() {
      this.widget.display();
      await this.refresh();
    }
    async refresh() {
      const info = await this.resolve();
      this.widget.setData({ mapJson: JSON.stringify(info) });
      this.widget.update();
    }
    async resolve() {
      const map = await this.ctx.gbx.call("GetCurrentMapInfo");
      if (!map) return UNKNOWN;
      if (map.Name && map.AuthorNickname) {
        return { name: map.Name, author: map.AuthorNickname };
      }
      if (!map.UId) return UNKNOWN;
      const record = await this.ctx.maps.findByUid(map.UId);
      return record ? { name: record.name, author: record.authorNickname || "-" } : UNKNOWN;
    }
  };
  var index_default = definePlugin({
    create: (ctx) => new MapInfoPlugin(ctx)
  });
})();
