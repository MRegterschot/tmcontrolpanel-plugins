"use strict";
(() => {
  // ../packages/plugin-sdk/src/helpers.ts
  function throttle(ctx, fn, ms) {
    let waiting = false;
    let pending = false;
    const run = () => {
      fn();
      waiting = true;
      ctx.setTimeout(() => {
        waiting = false;
        if (pending) {
          pending = false;
          run();
        }
      }, ms);
    };
    return () => {
      if (waiting) pending = true;
      else run();
    };
  }

  // ../packages/plugin-sdk/src/index.ts
  function definePlugin(definition) {
    const register = globalThis.__tmcpRegister;
    if (typeof register === "function") register(definition);
    return definition;
  }

  // ta-leaderboard/src/index.ts
  function rankLeaderboard(records) {
    return [...records].sort((a, b) => {
      if (a.time === -1 && b.time === -1) return 0;
      if (a.time === -1) return 1;
      if (b.time === -1) return -1;
      return a.time - b.time;
    }).map((record, index) => ({ ...record, rank: index + 1 }));
  }
  var TALeaderboardPlugin = class {
    constructor(ctx) {
      this.ctx = ctx;
      this.widget = ctx.ui.widget({
        id: "ta-leaderboard-widget",
        template: "widgets/ta-leaderboard/ta-leaderboard",
        position: { x: 100, y: 55 }
      });
      this.render = throttle(ctx, () => this.send(), 100);
      ctx.on("beginMap", () => this.requestScores());
      ctx.on("finish", (waypoint) => this.onFinish(waypoint));
      ctx.on("playerConnect", (player) => this.onPlayerConnect(player));
      ctx.on("scores", (scores) => this.onScores(scores));
    }
    widget;
    records = [];
    render;
    async start() {
      this.widget.display();
      await this.requestScores();
    }
    onScores(scores) {
      if (scores.responseid !== this.ctx.pluginId) return;
      this.records = rankLeaderboard(
        scores.players.map((player) => ({
          rank: 0,
          login: player.login,
          name: player.name,
          time: player.bestracetime
        }))
      );
      this.render();
    }
    onPlayerConnect(player) {
      if (this.records.some((record) => record.login === player.login)) return;
      this.records = rankLeaderboard([
        ...this.records,
        { rank: 0, login: player.login, name: player.nickName, time: -1 }
      ]);
      this.render();
    }
    async onFinish(waypoint) {
      if (this.ctx.live.liveInfo.isWarmUp) return;
      let record = this.records.find((r) => r.login === waypoint.login);
      if (!record) {
        const player = await this.ctx.players.get(waypoint.login);
        record = { rank: 0, login: waypoint.login, name: player.nickName, time: -1 };
        this.records.push(record);
      }
      if (record.time !== -1 && waypoint.racetime >= record.time) return;
      record.time = waypoint.racetime;
      this.records = rankLeaderboard(this.records);
      this.render();
    }
    async requestScores() {
      await this.ctx.gbx.callScript("Trackmania.GetScores", this.ctx.pluginId);
    }
    send() {
      this.widget.setData({ recordsJson: JSON.stringify(this.records) });
      this.widget.update();
    }
  };
  var index_default = definePlugin({
    create: (ctx) => new TALeaderboardPlugin(ctx)
  });
})();
