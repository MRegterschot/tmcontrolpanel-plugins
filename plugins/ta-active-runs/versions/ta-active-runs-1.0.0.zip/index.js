"use strict";
(() => {
  // ../packages/plugin-sdk/src/helpers.ts
  function getSpectatorStatus(spectatorStatus) {
    return {
      spectator: spectatorStatus % 10 === 1,
      temporarySpectator: Math.floor(spectatorStatus / 10) % 10 === 1,
      pureSpectator: Math.floor(spectatorStatus / 100) % 10 === 1,
      autoTarget: Math.floor(spectatorStatus / 1e3) % 10 === 1,
      currentTargetId: Math.floor(spectatorStatus / 1e4)
    };
  }
  function throttle(ctx, fn, ms) {
    let waiting = false;
    let pending = false;
    const run = () => {
      fn();
      waiting = true;
      ctx.setTimeout(() => {
        waiting = false;
        if (pending) {
          pending = false;
          run();
        }
      }, ms);
    };
    return () => {
      if (waiting) pending = true;
      else run();
    };
  }

  // ../packages/plugin-sdk/src/index.ts
  function definePlugin(definition) {
    const register = globalThis.__tmcpRegister;
    if (typeof register === "function") register(definition);
    return definition;
  }

  // ta-active-runs/src/index.ts
  var FINISHED = -69;
  function sortActiveRuns(runs) {
    return [...runs].sort((a, b) => {
      if (a.checkpoint === FINISHED && b.checkpoint !== FINISHED) return 1;
      if (b.checkpoint === FINISHED && a.checkpoint !== FINISHED) return -1;
      if (a.checkpoint !== b.checkpoint) return b.checkpoint - a.checkpoint;
      return a.time - b.time;
    });
  }
  var TAActiveRunsPlugin = class {
    constructor(ctx) {
      this.ctx = ctx;
      this.widget = ctx.ui.widget({
        id: "ta-active-runs-widget",
        template: "widgets/ta-active-runs/ta-active-runs",
        position: { x: -156, y: 73.5 }
      });
      this.render = throttle(ctx, () => this.send(), 100);
      ctx.on("beginMap", () => this.reset());
      ctx.on("playerConnect", (player) => this.onPlayerConnect(player));
      ctx.on("playerInfo", (player) => this.onPlayerInfo(player));
      ctx.on("playerDisconnect", (login) => this.onPlayerDisconnect(login));
      ctx.on("startLine", (event) => this.resetRun(event));
      ctx.on("giveUp", (event) => this.resetRun(event));
      ctx.on("skipOutro", (event) => this.resetRun(event));
      ctx.on("checkpoint", (waypoint) => this.onCheckpoint(waypoint));
      ctx.on("finish", (waypoint) => this.onFinish(waypoint));
    }
    widget;
    runs = [];
    render;
    async start() {
      this.widget.display();
      await this.reset();
    }
    onPlayerConnect(player) {
      if (getSpectatorStatus(player.spectatorStatus).spectator) return;
      if (this.runs.some((run) => run.login === player.login)) return;
      this.runs.push({ login: player.login, name: player.nickName, time: 0, checkpoint: 0 });
      this.render();
    }
    onPlayerDisconnect(login) {
      if (!this.runs.some((run) => run.login === login)) return;
      this.runs = this.runs.filter((run) => run.login !== login);
      this.render();
    }
    onPlayerInfo(player) {
      if (getSpectatorStatus(player.spectatorStatus).spectator) {
        this.runs = this.runs.filter((run) => run.login !== player.login);
      } else {
        const run = this.runs.find((r) => r.login === player.login);
        if (run) {
          run.time = 0;
          run.checkpoint = 0;
        } else {
          this.runs.push({ login: player.login, name: player.nickName, time: 0, checkpoint: 0 });
        }
      }
      this.render();
    }
    resetRun(event) {
      const run = this.runs.find((r) => r.login === event.login);
      if (!run) return;
      run.time = 0;
      run.checkpoint = 0;
      this.render();
    }
    onCheckpoint(waypoint) {
      const run = this.runs.find((r) => r.login === waypoint.login);
      if (!run) return;
      run.time = waypoint.racetime;
      run.checkpoint = waypoint.checkpointinrace + 1;
      this.render();
    }
    onFinish(waypoint) {
      const run = this.runs.find((r) => r.login === waypoint.login);
      if (!run) return;
      run.time = waypoint.racetime;
      run.checkpoint = FINISHED;
      this.render();
    }
    async reset() {
      const playerList = await this.ctx.gbx.call("GetPlayerList", 1e3, 0);
      const mainServer = await this.ctx.gbx.call("GetMainServerPlayerInfo");
      this.runs = (Array.isArray(playerList) ? playerList : []).filter(
        (player) => player.Login && player.Login !== mainServer?.Login && !getSpectatorStatus(player.SpectatorStatus).spectator
      ).map((player) => ({ login: player.Login, name: player.NickName, time: 0, checkpoint: 0 }));
      this.render();
    }
    send() {
      this.runs = sortActiveRuns(this.runs);
      this.widget.setData({ activeRunsJson: JSON.stringify(this.runs) });
      this.widget.update();
    }
  };
  var index_default = definePlugin({
    create: (ctx) => new TAActiveRunsPlugin(ctx)
  });
})();
