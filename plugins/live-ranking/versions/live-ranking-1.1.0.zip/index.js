"use strict";
(() => {
  // @tmcontrolpanel/plugin-sdk/src/helpers.ts
  function getSpectatorStatus(spectatorStatus) {
    return {
      spectator: spectatorStatus % 10 === 1,
      temporarySpectator: Math.floor(spectatorStatus / 10) % 10 === 1,
      pureSpectator: Math.floor(spectatorStatus / 100) % 10 === 1,
      autoTarget: Math.floor(spectatorStatus / 1e3) % 10 === 1,
      currentTargetId: Math.floor(spectatorStatus / 1e4)
    };
  }
  var TEAM_COLORS = {
    red: { mainColor: "A22", secondaryColor: "922", textColor: "DDD" },
    blue: { mainColor: "22A", secondaryColor: "229", textColor: "DDD" },
    default: { mainColor: "", secondaryColor: "", textColor: "" }
  };
  function getTeamColors(teamName) {
    if (!teamName) return TEAM_COLORS.default;
    return TEAM_COLORS[teamName.toLowerCase()] ?? TEAM_COLORS.default;
  }
  function throttle(ctx, fn, ms) {
    let waiting = false;
    let pending = false;
    const run = () => {
      fn();
      waiting = true;
      ctx.setTimeout(() => {
        waiting = false;
        if (pending) {
          pending = false;
          run();
        }
      }, ms);
    };
    return () => {
      if (waiting) pending = true;
      else run();
    };
  }

  // @tmcontrolpanel/plugin-sdk/src/index.ts
  function definePlugin(definition) {
    const register = globalThis.__tmcpRegister;
    if (typeof register === "function") register(definition);
    return definition;
  }

  // plugins/live-ranking/src/index.ts
  var LiveRankingPlugin = class {
    constructor(ctx) {
      this.ctx = ctx;
      this.widget = ctx.ui.widget({
        id: "live-ranking-widget",
        template: "widgets/live-ranking/live-ranking",
        position: { x: 100, y: 55 }
      });
      this.render = throttle(ctx, () => this.send(), 100);
      ctx.on("scores", (scores) => this.onScores(scores));
      ctx.on("beginMatch", () => this.reset());
      ctx.on("playerConnect", (player) => this.onPlayerConnect(player));
      ctx.on("playerDisconnect", (login) => this.onPlayerDisconnect(login));
      ctx.on("playerInfo", (player) => this.onPlayerInfo(player));
      ctx.on("updatedSettings", (info) => this.onUpdatedSettings(info));
      ctx.on("playerUpdated", (round) => this.onPlayerUpdated(round));
    }
    widget;
    rankings = [];
    pointsLimit = -1;
    render;
    async start() {
      this.widget.display();
      await this.reset();
    }
    teamColors(teamId) {
      return getTeamColors(this.ctx.live.liveInfo.teams?.[teamId]?.name);
    }
    isSpectating(player) {
      return getSpectatorStatus(player.spectatorStatus).spectator || this.ctx.live.reverseCupGetPlayerStatus(player.login).spectator;
    }
    onPlayerConnect(player) {
      if (this.isSpectating(player)) return;
      if (this.rankings.some((r) => r.login === player.login)) return;
      this.rankings.push({
        login: player.login,
        name: player.nickName,
        rank: 0,
        points: 0,
        team: this.teamColors(player.teamId)
      });
      this.render();
    }
    onPlayerDisconnect(login) {
      if (!this.rankings.some((r) => r.login === login)) return;
      this.rankings = this.rankings.filter((r) => r.login !== login);
      this.render();
    }
    onPlayerInfo(player) {
      const ranking = this.rankings.find((r) => r.login === player.login);
      if (this.isSpectating(player)) {
        if (!ranking || ranking.points > 0) return;
        this.rankings = this.rankings.filter((r) => r.login !== player.login);
      } else if (!ranking) {
        this.rankings.push({
          login: player.login,
          name: player.nickName,
          rank: 0,
          points: 0,
          team: this.teamColors(player.teamId)
        });
      } else {
        ranking.name = player.nickName;
        ranking.team = this.teamColors(player.teamId);
      }
      this.render();
    }
    onPlayerUpdated(round) {
      const ranking = this.rankings.find((r) => r.login === round.login);
      if (!ranking) return;
      ranking.points = round.matchPoints;
      this.render();
    }
    onUpdatedSettings(info) {
      this.pointsLimit = info.pointsLimit || -1;
      this.render();
    }
    onScores(scores) {
      if (scores.responseid !== this.ctx.pluginId && scores.section !== "EndRound") return;
      const { live } = this.ctx;
      const { liveInfo } = live;
      this.rankings = [];
      for (const player of scores.players) {
        if (liveInfo.type === "reversecup" && player.matchpoints === -1e4) continue;
        if (player.matchpoints === 0) {
          const active = live.findActivePlayer(player.login);
          if (!active || getSpectatorStatus(active.spectatorStatus).spectator) continue;
        }
        this.rankings.push({
          rank: 0,
          login: player.login,
          name: player.name,
          points: player.matchpoints,
          team: getTeamColors(liveInfo.teams?.[player.team]?.name)
        });
      }
      this.render();
    }
    async reset() {
      this.pointsLimit = this.ctx.live.liveInfo.pointsLimit || -1;
      await this.ctx.gbx.callScript("Trackmania.GetScores", this.ctx.pluginId);
    }
    send() {
      this.rankings.sort((a, b) => b.points - a.points);
      this.rankings.forEach((ranking, index) => ranking.rank = index + 1);
      this.widget.setData({
        rankingsJson: JSON.stringify(this.rankings),
        mode: this.ctx.live.liveInfo.type,
        pointsLimit: this.pointsLimit
      });
      this.widget.update();
    }
  };
  var index_default = definePlugin({
    create: (ctx) => new LiveRankingPlugin(ctx)
  });
})();
